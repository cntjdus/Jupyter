# Jupiter Tutorial

## 1.  What is Jupyter notebook? 

 The Jupyter Notebook is the original web application for creating and sharing computational documents. It offers a simple, streamlined, document-centric experience.

## 2. Live Code Example


```python
3+4
```




    7




```python
# adding two parameter
def add(a, b):
    return a+b
```


```python
add(5, 4)
```




    9



## 3. Equation


```python
#sqrt(x^2+y^2+Z^2)
```



https://nbclassic.readthedocs.io/en/latest/examples/Notebook/Typesetting%20Equations.html

## 4. Visualization

### 4.1 image


```python
from IPython.display import Image

Image(url="https://raw.githubusercontent.com/jupyter/jupyter/master/docs/source/_static/images/jupyter.png", width=400, height=100)
```




<img src="https://raw.githubusercontent.com/jupyter/jupyter/master/docs/source/_static/images/jupyter.png" width="400" height="100"/>



### 4.2 video


```python
from IPython.display import YouTubeVideo

YouTubeVideo('vJwrhL5f8Y')
```





<iframe
    width="400"
    height="300"
    src="https://www.youtube.com/embed/vJwrhL5f8Y"
    frameborder="0"
    allowfullscreen

></iframe>




### 4.3 table


```python
import pandas as pd

url="https://raw.githubusercontent.com/cs109/2014_data/master/countries.csv"
pd.read_csv(url, nrows=10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country</th>
      <th>Region</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Algeria</td>
      <td>AFRICA</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Angola</td>
      <td>AFRICA</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Benin</td>
      <td>AFRICA</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Botswana</td>
      <td>AFRICA</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Burkina</td>
      <td>AFRICA</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Burundi</td>
      <td>AFRICA</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Cameroon</td>
      <td>AFRICA</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Cape Verde</td>
      <td>AFRICA</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Central African Republic</td>
      <td>AFRICA</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Chad</td>
      <td>AFRICA</td>
    </tr>
  </tbody>
</table>
</div>



### 4.4 chart


```python
import matplotlib.pyplot as plt

plt.plot([1,2,3,4])
plt.ylabel('result')
plt.show()
```


    
![png](output_19_0.png)
    



```python
[More Examples click here](https://matplotlib.org/examples/index.html)
```

## 5. Performance check


```python
%timeit 3+4
```

    14.5 ns ± 1.02 ns per loop (mean ± std. dev. of 7 runs, 100,000,000 loops each)
    


```python
%timeit add(3, 4)
```

    93.7 ns ± 16.7 ns per loop (mean ± std. dev. of 7 runs, 10,000,000 loops each)
    


```python
%%timeit
a = [1,2,3]
a = [x+1 for x in a]
```

    313 ns ± 240 ns per loop (mean ± std. dev. of 7 runs, 1,000,000 loops each)
    


```python
%%timeit
b = [1,2,3]
for i in range(len(b)):
    b[i] = b[i] + 1
```

    294 ns ± 33.7 ns per loop (mean ± std. dev. of 7 runs, 1,000,000 loops each)
    


```python

```
